Installation Instructions
Operating System
- Ubuntu 20.x

Software Requirements
- Apache
- PHP 5.x or higher
- MySQL

Setup Instructions
1. Create MySQL Database and User
 - Create a MySQL database and user with ALL privileges.
 - Note the credentials for use in the next steps.

2. Extract Backend Files
	mkdir -p /home/indiamart/public_html/kumb
	cd /home/indiamart/public_html/kumb
	tar -xvf backend.tar

3. Import Database Schema
Run the SQL script:
	mysql -u <username> -p <database_name> < sqlquery.txt

4. Configure Database Connection
Edit the following file:
	/home/indiamart/public_html/kumb/modules-3.0/api/con.php

Update:
	MySQL IP address
	Username
	Password
	Database name
	
5. Extract CRM Files
	mkdir -p /home/indiamart/public_html/crm-kumb
	cd /home/indiamart/public_html/crm-kumb
	tar -xvf crmbuild.tar

Apache Virtual Hosts
CRM VirtualHost
	<VirtualHost *:80>
	    ServerName crm.kumb.local
	    ServerAlias crm.kumb.local
	    ServerAdmin webmaster@hellotravel.com
	    DocumentRoot /home/indiamart/public_html/crm-kumb

	    <Directory /home/indiamart/public_html/crm-kumb/>
		RewriteEngine On
		DirectoryIndex main.html
		Options Indexes FollowSymLinks
		AllowOverride All
		Options -MultiViews
		RewriteCond %{REQUEST_FILENAME} !-f
		RewriteRule ^ main.html [QSA,L]
		Require all granted
	    </Directory>

	    ErrorLog ${APACHE_LOG_DIR}/error.log
	    CustomLog ${APACHE_LOG_DIR}/access.log combined
	</VirtualHost>

Backend VirtualHost
	<VirtualHost *:80>
	    ServerName kumb.local
	    ServerAlias kumb.local
	    ServerAdmin webmaster@hellotravel.com
	    DocumentRoot /home/indiamart/public_html/kumb

	    <Directory /home/indiamart/public_html/kumb/>
		Options -Indexes +FollowSymLinks
		DirectoryIndex home.php
		AllowOverride All
		Require all granted
	    </Directory>

	    ErrorLog ${APACHE_LOG_DIR}/api.log
	    CustomLog ${APACHE_LOG_DIR}/api.log
	</VirtualHost>

Permissions & Ownership
Create Image Directory
	mkdir -p /home/indiamart/public_html/kumb/images/kumb
	chmod 777 -R /home/indiamart/public_html/kumb/images/kumb

Add the following lines to /etc/hosts
	127.0.0.1  kumb.local crm.kumb.local

