# Auto Face Clustering Project

## Features
- Detects faces from camera in real-time.
- Saves each detected face as an image inside `faces/` folder with random names.
- Shows live video stream in browser.
- Search for person live
- RTSP link as input feed

## Setup Instructions
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the app:
   ```bash
   python fauto.py
   ```

3. Open browser:
   ```
   http://127.0.0.1:5000
   ```

## Saved Faces
All faces will be stored in the `faces/` directory with unique filenames.
