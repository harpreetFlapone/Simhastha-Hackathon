import face_recognition
import os
import pickle
import cv2

DATASET_DIR = "static/faces"
OUTPUT_FILE = "trained_faces.pkl"

def train_faces():
    known_encodings = []
    known_names = []

    for person_name in os.listdir(DATASET_DIR):
        person_dir = os.path.join(DATASET_DIR, person_name)
        if not os.path.isdir(person_dir):
            continue

        print(f"[INFO] Processing {person_name}...")

        for img_file in os.listdir(person_dir):
            img_path = os.path.join(person_dir, img_file)
            image = cv2.imread(img_path)
            if image is None:
                continue

            rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            boxes = face_recognition.face_locations(rgb, model="hog")
            encodings = face_recognition.face_encodings(rgb, boxes)

            for enc in encodings:
                known_encodings.append(enc)
                known_names.append(person_name)

    print(f"[INFO] Saving {len(known_names)} faces to {OUTPUT_FILE}")
    with open(OUTPUT_FILE, "wb") as f:
        pickle.dump({"encodings": known_encodings, "names": known_names}, f)

if __name__ == "__main__":
    train_faces()
