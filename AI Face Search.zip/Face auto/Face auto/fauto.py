import cv2
import face_recognition
import numpy as np
import os
import uuid
import datetime
import csv
from flask import Flask, render_template, Response, send_file, request
from werkzeug.utils import secure_filename

# -------------------- Flask App --------------------
app = Flask(__name__, static_folder="static", template_folder="templates")

# -------------------- Webcam Setup --------------------
CAM_INDEX = "RTSP Addrases"
cap = cv2.VideoCapture(CAM_INDEX)

# -------------------- Directories --------------------
KNOWN_FACES_DIR = "static/faces/known"
UNKNOWN_FACES_DIR = "static/faces/unknown"
UPLOAD_FOLDER = "static/uploads"

os.makedirs(KNOWN_FACES_DIR, exist_ok=True)
os.makedirs(UNKNOWN_FACES_DIR, exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# -------------------- Face Recognition Setup --------------------
known_face_encodings = []
known_face_names = []

# Load known faces
for filename in os.listdir(KNOWN_FACES_DIR):
    path = os.path.join(KNOWN_FACES_DIR, filename)
    img = face_recognition.load_image_file(path)
    enc = face_recognition.face_encodings(img)
    if len(enc) > 0:
        known_face_encodings.append(enc[0])
        known_face_names.append(os.path.splitext(filename)[0])
print(f"✅ Loaded {len(known_face_names)} known faces")

# Unknown face memory
unknown_faces_memory = []
PROMOTE_THRESHOLD = 5
FRAME_RESIZE = 0.5
PROCESS_EVERY_N_FRAMES = 2

# Detection history
detection_history = []  # [{'name':..., 'time':..., 'image':..., 'folder':...}]

# Face search globals
search_faces = []  # list of dicts: {'name':..., 'encoding':...}

# -------------------- Helper Functions --------------------
def save_face(face_img, known=True, filename=None):
    folder = KNOWN_FACES_DIR if known else UNKNOWN_FACES_DIR
    subfolder = "known" if known else "unknown"
    if filename is None:
        filename = f"{uuid.uuid4().hex}.jpg"
    path = os.path.join(folder, filename)
    cv2.imwrite(path, face_img)
    return filename, subfolder

def add_to_history(name, face_img):
    filename, subfolder = save_face(face_img, known=(name != "Unknown"))
    entry = {
        'name': name,
        'time': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'image': filename,
        'folder': subfolder
    }
    detection_history.append(entry)

def get_summary():
    summary = {}
    for item in detection_history:
        name = item["name"]
        summary[name] = {
            "count": summary.get(name, {}).get("count", 0) + 1,
            "last_seen": item["time"],
            "image": item["image"],
            "folder": item["folder"]
        }
    return summary

# -------------------- Video Stream Generators --------------------
def gen_frames():
    frame_count = 0
    face_names_frame = []

    while True:
        success, frame = cap.read()
        if not success:
            break

        small_frame = cv2.resize(frame, (0, 0), fx=FRAME_RESIZE, fy=FRAME_RESIZE)
        rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

        frame_count += 1
        if frame_count % PROCESS_EVERY_N_FRAMES == 0:
            face_locations = face_recognition.face_locations(rgb_small_frame)
            face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

            face_names_frame.clear()
            for face_encoding, face_location in zip(face_encodings, face_locations):
                matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=0.5)
                name = "Unknown"

                if True in matches:
                    best_idx = np.argmin(face_recognition.face_distance(known_face_encodings, face_encoding))
                    if matches[best_idx]:
                        name = known_face_names[best_idx]
                else:
                    matched_memory = False
                    for mem in unknown_faces_memory:
                        if face_recognition.compare_faces([mem['encoding']], face_encoding, tolerance=0.5)[0]:
                            mem['counter'] += 1
                            matched_memory = True
                            if mem['counter'] >= PROMOTE_THRESHOLD:
                                new_name = f"person_{uuid.uuid4().hex}"
                                save_face(mem['face_img'], known=True, filename=new_name+".jpg")
                                known_face_encodings.append(mem['encoding'])
                                known_face_names.append(new_name)
                                unknown_faces_memory.remove(mem)
                            break
                    if not matched_memory:
                        top, right, bottom, left = face_location
                        face_img = small_frame[top:bottom, left:right]
                        unknown_faces_memory.append({'encoding': face_encoding, 'counter':1, 'face_img': face_img})

                top, right, bottom, left = face_location
                top = int(top / FRAME_RESIZE)
                right = int(right / FRAME_RESIZE)
                bottom = int(bottom / FRAME_RESIZE)
                left = int(left / FRAME_RESIZE)
                face_names_frame.append((top, right, bottom, left, name))

                face_crop = frame[top:bottom, left:right]
                if face_crop.size > 0:
                    add_to_history(name, face_crop)

        for top, right, bottom, left, name in face_names_frame:
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, name, (left, top-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)

        ret, buffer = cv2.imencode('.jpg', frame)
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')

def gen_search_frames():
    global search_faces
    colors = [(0,0,255), (255,0,0), (0,255,255), (255,0,255), (0,128,255)]

    while True:
        success, frame = cap.read()
        if not success or not search_faces:
            break

        small_frame = cv2.resize(frame, (0, 0), fx=FRAME_RESIZE, fy=FRAME_RESIZE)
        rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        for face_encoding, face_location in zip(face_encodings, face_locations):
            for idx, sf in enumerate(search_faces):
                match = face_recognition.compare_faces([sf['encoding']], face_encoding, tolerance=0.5)[0]
                if match:
                    color = colors[idx % len(colors)]
                    top, right, bottom, left = face_location
                    top = int(top / FRAME_RESIZE)
                    right = int(right / FRAME_RESIZE)
                    bottom = int(bottom / FRAME_RESIZE)
                    left = int(left / FRAME_RESIZE)

                    cv2.rectangle(frame, (left, top), (right, bottom), color, 3)
                    cv2.putText(frame, f"Match: {sf['name']}", (left, top-10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

        ret, buffer = cv2.imencode('.jpg', frame)
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')

# -------------------- Flask Routes --------------------
@app.route('/')
def index():
    return render_template("index.html")

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/dashboard')
def dashboard():
    return render_template("dashboard.html", summary=get_summary())

@app.route('/search', methods=['GET', 'POST'])
def search():
    global search_faces
    search_faces = []

    if request.method == 'POST':
        if 'file' not in request.files:
            return "No file uploaded", 400
        files = request.files.getlist('file')
        if not files or all(f.filename == '' for f in files):
            return "No valid files", 400

        uploaded_names = []
        for file in files:
            if file and file.filename:
                filename = secure_filename(file.filename)
                filepath = os.path.join(UPLOAD_FOLDER, filename)
                file.save(filepath)

                img = face_recognition.load_image_file(filepath)
                encs = face_recognition.face_encodings(img)
                if len(encs) > 0:
                    search_faces.append({'name': os.path.splitext(filename)[0], 'encoding': encs[0]})
                    uploaded_names.append(filename)

        if not search_faces:
            return "No faces found in uploaded images", 400

        return render_template("search_live.html", images=uploaded_names)

    return render_template("search.html")

@app.route('/search_feed')
def search_feed():
    return Response(gen_search_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/export_csv')
def export_csv():
    filename = "detection_history.csv"
    with open(filename, mode="w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Name", "Time", "Folder", "Image"])
        for item in detection_history:
            writer.writerow([item["name"], item["time"], item["folder"], item["image"]])
    return send_file(filename, as_attachment=True)

# -------------------- Run App --------------------
if __name__ == "__main__":
    print("Flapone Aviation - Face Recognition with Multi-Image Search Starting...")
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
